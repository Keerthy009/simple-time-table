from django.contrib import admin
from .models import Day, Todo
# Register your models here.
admin.site.register(Day)
admin.site.register(Todo)
