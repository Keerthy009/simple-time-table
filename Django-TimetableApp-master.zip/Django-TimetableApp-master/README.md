# Django-TimetableApp
Simple timetable app for CoEP S.Y. Comp 2015-16. Created using Django
